open Core
[@@@ocaml.warning "-32"]
(*path to get a random recipe*)
let rand = 
  Command.basic 
  ~summary: "get a random recipe"
  Command.Let_syntax.( 
    let%map_open x = anon ("x" %: string) in fun () -> print_endline x)

(*path to get a recipe from an inputted ID number *)
let id = 
  Command.basic 
  ~summary: "get a recipe based on an ID number"
  Command.Let_syntax.( 
    let%map_open x = anon ("x" %: int) in fun () -> print_endline (string_of_int x))

(*path to get a recipe from an inputted meal name*)
let name = 
  Command.basic 
  ~summary: "get a recipe based on the meal name"

let ingredient = 
  Command.basic
  ~summary: "get a random recipe that contains user-specified ingredient"

(*path to get a recipe from an inputted cuisine name and optional list of restrictions*)
let cuisine = 
  Command.basic 
  ~summary: "get recipe based on a cuisine type and list of ingredients to exclude"

let vegan = 
  Command.basic 
  ~summary: "get vegan recipe, exclude list of ingredients if provided by user"

let vegetarian = 
  Command.basic 
  ~summary: "get vegetarian recipe, exclude list of ingredients if provided by user"

(*group together commands above as well as tags for showing list of cuisine types available and list of ingredients available to users*)
let command = 
  Command.group
  ~summary: "receive recipes"
  ["rand", rand; "id", id]

let () = Command_unix.run command
(*print_string "hello"*)